import React from "react";
import SignUpPage from "../ComponentsSignUp/SignUpPage";
function SignUp() {
  return (
    <div>
      <SignUpPage></SignUpPage>
    </div>
  );
}

export default SignUp;
